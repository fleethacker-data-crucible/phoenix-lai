// Chat engine: model loading (GPU with CPU fallback), Gemma 4 chat template, KV-cache reuse across turns,
// sampling and streaming. C# 5 only.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace Phoenix
{
    public interface ILanguageModel : IDisposable
    {
        // Runs one token at position pos (positions must be fed in order); returns logits.
        float[] Forward(int token, int pos);
        // Feeds tokens[start .. start+count) at positions start..start+count-1; returns the last logits.
        float[] Prefill(IList<int> tokens, int start, int count);
        void Reset();
        int ContextLength { get; }
        int VocabSize { get; }
        // Earliest cached position that can be kept after `fed` tokens (0 = any; ring caches return more).
        int MinReuse(int fed);
        // Instant Recall: save the KV cache of positions pos0.. and put it back at another position (re-rotated).
        bool CanRecall { get; }
        // Speculative verification: feeds tokens[start .. start+count) (count <= 16) through the layers in one batched pass
        // (false when the model has no batched path); RowLogits(i) then computes the logits after token i on demand, so
        // the output layer (566 MB per row on Gemma's 262K vocabulary) is only paid for rows that are actually checked.
        bool PrefillRows(IList<int> tokens, int start, int count);
        float[] RowLogits(int row);
        KvSnapshot CaptureKv(int pos0, int count);
        void SpliceKv(KvSnapshot s, int dst0);
    }

    public sealed class ChatMessage
    {
        public string Role;   // "system", "user", "assistant"
        public string Text;
        public List<byte[]> Images;   // image files (PNG / JPEG ...) shown before the text of a user message; null: none
        public ChatMessage(string role, string text) { Role = role; Text = text; }
    }

    public sealed class GenerationStats
    {
        public int PromptTokens, ReusedTokens, GeneratedTokens, RecalledTokens;
        public int DraftedTokens, AcceptedTokens;   // speculation: guessed tokens checked / kept   // RecalledTokens: part of PromptTokens spliced, not read
        public double PromptSeconds, GenerateSeconds;
        public string StopReason = "";
        public double PromptTokensPerSecond { get { return PromptSeconds > 0 ? PromptTokens / PromptSeconds : 0; } }
        public double TokensPerSecond { get { return GenerateSeconds > 0 ? GeneratedTokens / GenerateSeconds : 0; } }
    }

    public delegate void TextCallback(string text);
    public delegate bool CancelCheck();

    public sealed class ChatEngine : IDisposable
    {
        public readonly string ModelPath, ModelName, Backend;
        readonly List<int> _banned = new List<int>();   // control tokens the model may not generate (see constructor)
        public readonly Tokenizer Tokenizer;
        public readonly int ContextLength;

        readonly GgufFile _gguf;
        readonly GpuDevice _gpu;
        readonly ILanguageModel _model;
        readonly List<int> _fed = new List<int>();   // tokens whose K/V are in the cache, by position
        readonly int _turn, _turnEnd, _channel, _channelEnd;   // Gemma 4 chat template (<|turn>role ... <turn|>)
        readonly int _eot;                                      // end of turn (<turn|>)

        ChatEngine(string path, GgufFile g, GpuDevice gpu, ILanguageModel model, string backend, int ctx)
        {
            ModelPath = path; _gguf = g; _gpu = gpu; _model = model; Backend = backend; ContextLength = ctx;
            ModelName = g.Has("general.name") ? g.GetString("general.name") : Path.GetFileNameWithoutExtension(path);
            Tokenizer = new Tokenizer(g);
            _turn = TokenId("<|turn>");
            _turnEnd = TokenId("<turn|>");
            _channel = TokenId("<|channel>");
            _channelEnd = TokenId("<channel|>");
            // Gemma's native tool-call / thinking control tokens are never sampled: with the file-tool instructions in the
            // prompt it would otherwise open a native tool call as its first token and the reply ended empty (2026-10-16).
            // The app's own tools are plain-text tags (<read>, <write>, <list>), which it then uses instead.
            foreach (string name in new string[] { "<|tool>", "<tool|>", "<|tool_call>", "<tool_call|>", "<|tool_response>", "<tool_response|>", "<|think|>", "<|channel>", "<channel|>" })
            {
                int id = TokenId(name);
                if (id >= 0) _banned.Add(id);
            }
            if (_turn < 0 || _turnEnd < 0 || _channel < 0 || _channelEnd < 0)
                throw new NotSupportedException("Model has no Gemma 4 chat template (PhoenixLAI runs Gemma 4 models).");
            _eot = _turnEnd;
            string tmpl = g.Has("tokenizer.chat_template") ? g.GetString("tokenizer.chat_template") : null;
            _emptyThought = tmpl == null || tmpl.Contains("'<|channel>thought\\n<channel|>'");
            // Vision: the Gemma 4 model's projector file next to it (loaded on the first image, once).
            _boi = TokenId("<|image>"); _eoi = TokenId("<image|>");
            GemmaGpu gg = model as GemmaGpu; GemmaCpu gc = model as GemmaCpu;
            if (_boi >= 0 && _eoi >= 0 && (gg != null || gc != null))
            {
                try { MmprojPath = VisionEncoder.FindFor(path, gg != null ? gg.C.NEmbd : gc.C.NEmbd); } catch { MmprojPath = null; }
                if (gg != null) gg.ImageRow = ImageRow; else gc.ImageRow = ImageRow;
            }
        }

        // ---- images ----
        public readonly string MmprojPath;   // the vision projector found for this model (null: text only)
        public bool HasVision { get { return MmprojPath != null; } }
        readonly int _boi, _eoi;
        VisionEncoder _vision;
        readonly Dictionary<string, int> _imgByHash = new Dictionary<string, int>();
        readonly Dictionary<int, float[][]> _imgRows = new Dictionary<int, float[][]>();
        readonly List<int> _imgOrder = new List<int>();   // least recently used first
        int _imgNext = 1;
        const int ImageKeep = 64;                         // encoded images kept in RAM (a 280-token 12B image is ~4 MB)
        public string LastVisionInfo;                     // for the log: size, tokens, time of the last encoding

        float[] ImageRow(int tok)
        {
            float[][] rows;
            if (!_imgRows.TryGetValue(ImageTokens.Image(tok), out rows)) throw new InvalidOperationException("Unknown image token.");
            return rows[ImageTokens.Index(tok)];
        }

        // The soft-token ids of an image file, encoding it (and loading the vision tower) the first time it is seen.
        List<int> ImageIds(byte[] file)
        {
            if (MmprojPath == null) throw new NotSupportedException("This model has no vision projector (mmproj) in the models folder, so it cannot read images.");
            string key;
            using (System.Security.Cryptography.SHA256 sha = System.Security.Cryptography.SHA256.Create()) key = Convert.ToBase64String(sha.ComputeHash(file));
            int img;
            if (!_imgByHash.TryGetValue(key, out img))
            {
                Stopwatch sw = Stopwatch.StartNew();
                if (_vision == null)
                {
                    _vision = new VisionEncoder(MmprojPath, _gpu);
                    GemmaGpu gg = _model as GemmaGpu;
                    if (gg != null) gg.BidiImages = _vision.Kind == "gemma4uv";   // 12B: image tokens see each other both ways
                    Dbg.Msg("engine", "vision tower " + Path.GetFileName(MmprojPath) + " (" + _vision.Kind + ") loaded on the " + _vision.Backend + " in " + sw.ElapsedMilliseconds + " ms");
                }
                RgbImage pic = RgbImage.Decode(file);
                long t0 = sw.ElapsedMilliseconds;
                float[][] rows = _vision.Encode(pic);
                img = _imgNext++;
                _imgByHash[key] = img; _imgRows[img] = rows;
                LastVisionInfo = pic.W + "x" + pic.H + " image -> " + rows.Length + " tokens in " + (sw.ElapsedMilliseconds - t0) + " ms";
                Dbg.Msg("engine", LastVisionInfo);
                while (_imgOrder.Count >= ImageKeep)
                {
                    int old = _imgOrder[0]; _imgOrder.RemoveAt(0); _imgRows.Remove(old);
                    string ok = null; foreach (KeyValuePair<string, int> kv in _imgByHash) if (kv.Value == old) { ok = kv.Key; break; }
                    if (ok != null) _imgByHash.Remove(ok);
                }
            }
            _imgOrder.Remove(img); _imgOrder.Add(img);
            List<int> ids = new List<int>();
            ids.Add(_boi);
            for (int i = 0; i < _imgRows[img].Length; i++) ids.Add(ImageTokens.Make(img, i));
            ids.Add(_eoi);
            return ids;
        }

        int TokenId(string text)
        {
            for (int i = 0; i < Tokenizer.VocabSize; i++) if (Tokenizer.Tokens[i] == text) return i;
            return -1;
        }

        // Gemma 4 template (thinking off): <bos><|turn>system\nsys<turn|>\n<|turn>user\nmsg<turn|>\n<|turn>model\n
        // <|channel>thought\n<channel|> -- the empty thought channel tells the model to answer directly.
        List<int> GemmaTemplate(IList<ChatMessage> messages)
        {
            List<int> ids = new List<int>();
            ids.Add(Tokenizer.BosId);
            foreach (ChatMessage m in messages)
            {
                ids.Add(_turn);
                if (m.Role == "assistant")
                {
                    // A model turn is written exactly as it was generated (header, empty thought channel, the sampled
                    // tokens), so the KV cache of the reply is reused instead of re-reading it on the next request.
                    ids.AddRange(Tokenizer.Encode("model\n", false, false));
                    if (_emptyThought)
                    {
                        ids.Add(_channel);
                        ids.AddRange(Tokenizer.Encode("thought\n", false, false));
                        ids.Add(_channelEnd);
                    }
                    ids.AddRange(ReplyIds(m.Text));
                }
                else if (m.Images != null && m.Images.Count > 0)
                {
                    // images first, then the text (Google's guidance), as <|image> soft tokens <image|>
                    ids.AddRange(Tokenizer.Encode(m.Role + "\n", false, false));
                    foreach (byte[] im in m.Images) ids.AddRange(ImageIds(im));
                    ids.AddRange(EncodeBody("", m.Text.Trim(), ids.Count));
                }
                else ids.AddRange(EncodeBody(m.Role + "\n", m.Text.Trim(), ids.Count));
                ids.Add(_turnEnd);
                ids.AddRange(Tokenizer.Encode("\n", false, false));
            }
            ids.Add(_turn);
            ids.AddRange(Tokenizer.Encode("model\n", false, false));
            if (_emptyThought)
            {
                ids.Add(_channel);
                ids.AddRange(Tokenizer.Encode("thought\n", false, false));
                ids.Add(_channelEnd);
            }
            return ids;
        }

        // Whether the model's own template closes the prompt with an empty thought channel when thinking is off: the 12B's
        // does ('<|channel>thought\n<channel|>' after "<|turn>model\n"); E2B / E4B's end at "<|turn>model\n" (with the
        // empty channel they planned out loud before answering). No template: keep the channel.
        readonly bool _emptyThought;

        // Loads a local .gguf file. Uses the GPU when Vulkan works, otherwise the CPU reference path.
        // KV cache format: Gemma keeps fp16 (its values have large outlier channels that 8 / 4-bit blocks lose: 54/64
        // top-1), and its sliding-window cache is small anyway.
        public static KvType KvFor(GgufFile g) { return KvType.F16; }

        bool _locked;   // holds ModelLock (released in Dispose)

        public static ChatEngine Load(string path, int contextLength, bool allowGpu, TextCallback log)
        {
            if (!File.Exists(path)) throw new FileNotFoundException("Model file not found.", path);
            lock (GpuGate.Lock) return LoadLocked(path, contextLength, allowGpu, log);
        }

        static ChatEngine LoadLocked(string path, int contextLength, bool allowGpu, TextCallback log)
        {
            ModelLock.Check();   // another Phoenix process has a model loaded: refuse (the CPU path would double the RAM too)
            GgufFile g = GgufFile.Open(path);
            GpuDevice gpu = null;
            ILanguageModel model = null;
            string backend;
            try
            {
                if (allowGpu)
                {
                    try
                    {
                        string garch = g.GetString("general.architecture");
                        if (!GemmaConfig.IsGemma(garch)) throw new NotSupportedException("Not a Gemma model (" + garch + "); PhoenixLAI runs Gemma 4.");
                        if (garch == "gemma-embedding2") throw new NotSupportedException("This is an embedding model (used for docs search), not a chat model.");
                        gpu = GpuDevice.Create();
                        if (log != null) log(gpu.Describe());
                        int ctx = contextLength;
                        ulong used0, budget0;
                        if (GemmaConfig.IsGemma(garch))
                        {
                            // the rewind buffer first: the auto context is planned around it
                            string swhy = null;
                            GemmaGpu.SwaSlack = gpu.MemoryBudget(out used0, out budget0)
                                ? ContextPlanner.ChooseSlack(g, path, (long)(budget0 - Math.Min(used0, budget0)), MemoryTrim.AvailableCommit(), ctx, out swhy)
                                : ContextPlanner.MinSlack;
                            if (log != null && swhy != null) log(swhy);
                        }
                        if (ctx <= 0)
                        {
                            ulong used, budget;
                            string why;
                            // VRAM, and system commit: on Windows the driver backs video memory with commit charge, so with a
                            // small page file a big cache can leave other programs unable to start (seen 2026-10-16).
                            if (gpu.MemoryBudget(out used, out budget))
                                ctx = ContextPlanner.Choose(g, path, true, (long)(budget - Math.Min(used, budget)), MemoryTrim.AvailableCommit(), out why);
                            else { ctx = 8192; why = "auto context 8192 (the driver does not report free VRAM)"; }
                            if (log != null) log(why);
                        }
                        model = new GemmaGpu(gpu, g, ctx, KvFor(g));
                        contextLength = ctx;
                    }
                    catch (Exception ex)
                    {
                        if (log != null) log("GPU unavailable (" + ex.Message + "); using the CPU.");
                        if (model != null) model.Dispose();
                        if (gpu != null) gpu.Dispose();
                        model = null; gpu = null;
                    }
                }
                if (model != null)
                {
                    backend = "GPU: " + gpu.DeviceName + (gpu.FallbackBytes > 0 ? " (partly in system memory)" : "");
                }
                else
                {
                    string arch = g.GetString("general.architecture");
                    if (!GemmaConfig.IsGemma(arch)) throw new NotSupportedException("Not a Gemma model (" + arch + "); PhoenixLAI runs Gemma 4.");
                    if (arch == "gemma-embedding2") throw new NotSupportedException("This is an embedding model (used for docs search), not a chat model.");
                    if (contextLength <= 0 || allowGpu)   // auto, or a GPU context that fell back here: size it for RAM
                    {
                        int requested = contextLength;
                        string why;
                        contextLength = ContextPlanner.Choose(g, path, false, MemoryTrim.AvailableRam(), MemoryTrim.AvailableCommit(), out why);
                        if (requested > 0) contextLength = Math.Min(requested, contextLength);
                        if (log != null) log(why);
                    }
                    model = new GemmaCpu(g, contextLength);
                    backend = "CPU";
                }
                ChatEngine eng = new ChatEngine(path, g, gpu, model, backend, contextLength);
                ModelLock.Acquire(path); eng._locked = true;   // held until Dispose (the CPU path too)
                return eng;
            }
            catch
            {
                if (model != null) model.Dispose();
                if (gpu != null) gpu.Dispose();
                g.Dispose();
                throw;
            }
        }

        // ---- Instant Recall ----
        // File contents the model read (registered by the server) are encoded as their own token run inside a message,
        // so their position in the prompt is known. The first time such a run is read, its KV cache is captured; when the
        // same file text comes up again (next message, another chat) it is spliced in instead of read: ~12x faster to the
        // first token for a 1,300-token file on Gemma 12B (4.7 s -> 0.4 s). Snapshots live in RAM up to RecallBudget.
        public static long RecallBudget = 3L << 30;
        const int RecallMinTokens = 64;
        readonly Dictionary<string, List<int>> _segIds = new Dictionary<string, List<int>>();
        readonly Dictionary<string, KvSnapshot> _recall = new Dictionary<string, KvSnapshot>();
        readonly List<string> _recallOrder = new List<string>();   // least recently used first
        long _recallBytes;
        sealed class Span { public int Start, Len; public string Key; }
        List<Span> _spans = new List<Span>();

        // Where snapshots are kept on disk (the connected project's .phoenix\recall folder; null = RAM only).
        // Files are named by a hash of the model and the text, so a changed file simply gets a new snapshot.
        public string RecallDir;
        public static long RecallDiskBudget = 8L << 30;

        string RecallPath(string text)
        {
            if (RecallDir == null) return null;
            using (System.Security.Cryptography.SHA256 sha = System.Security.Cryptography.SHA256.Create())
            {
                byte[] h = sha.ComputeHash(Encoding.UTF8.GetBytes(Path.GetFileName(ModelPath) + "\n" + text));
                return Path.Combine(RecallDir, BitConverter.ToString(h, 0, 16).Replace("-", "").ToLowerInvariant() + ".kv");
            }
        }

        KvSnapshot FindRecall(string key)
        {
            KvSnapshot s;
            if (_recall.TryGetValue(key, out s)) return s;
            string p = RecallPath(key);
            if (p == null || !File.Exists(p)) return null;
            try { s = KvSnapshot.Load(p); } catch { return null; }
            if (s != null) { StoreRecall(key, s); File.SetLastAccessTimeUtc(p, DateTime.UtcNow); }
            return s;
        }

        void SaveRecall(string key, KvSnapshot s)
        {
            string p = RecallPath(key);
            if (p == null) return;
            try
            {
                s.Save(p);
                // disk budget: drop the least recently used snapshots
                DirectoryInfo dir = new DirectoryInfo(RecallDir);
                List<FileInfo> files = new List<FileInfo>(dir.GetFiles("*.kv"));
                long total = 0; foreach (FileInfo f in files) total += f.Length;
                files.Sort(delegate(FileInfo a, FileInfo b) { return a.LastAccessTimeUtc.CompareTo(b.LastAccessTimeUtc); });
                for (int i = 0; total > RecallDiskBudget && i < files.Count - 1; i++) { total -= files[i].Length; files[i].Delete(); }
            }
            catch { }
        }

        // Reads a file on its own and saves its snapshot (the /recall pre-read). Clears the conversation cache.
        // Returns false when the text is too short, already saved, or the model cannot recall.
        public bool PreRead(string text, CancelCheck cancel)
        {
            lock (GpuGate.Lock)
            {
                if (text == null || text.Length < 300 || !_model.CanRecall) return false;
                RegisterRecall(text);
                List<int> ids;
                if (!_segIds.TryGetValue(text, out ids) || ids.Count < RecallMinTokens || ids.Count + 16 > ContextLength) return false;
                if (FindRecall(text) != null) return false;
                KvSnapshot s = ReadAlone(text, ids, cancel);
                return s != null;
            }
        }

        KvSnapshot ReadAlone(string key, List<int> segIds, CancelCheck cancel)
        {
            List<int> alone = new List<int>();
            alone.Add(Tokenizer.BosId); alone.Add(_turn); alone.AddRange(Tokenizer.Encode("user\n", false, false));
            int at = alone.Count;
            alone.AddRange(segIds);
            _model.Reset(); _fed.Clear();
            for (int i = 0; i < alone.Count; i += 512)
            {
                if (cancel != null && cancel()) return null;
                _model.Prefill(alone, i, Math.Min(512, alone.Count - i));
            }
            KvSnapshot s = _model.CaptureKv(at, segIds.Count);
            StoreRecall(key, s);
            SaveRecall(key, s);
            return s;
        }

        public void RegisterRecall(string text)
        {
            if (text == null || text.Length < 300 || _segIds.ContainsKey(text) || !_model.CanRecall) return;
            _segIds[text] = Tokenizer.Encode(text, false, false);
            if (_segIds.Count > 256) { foreach (string k in new List<string>(_segIds.Keys)) { if (!_recall.ContainsKey(k)) { _segIds.Remove(k); break; } } }
        }

        public long RecallBytes { get { return _recallBytes; } }
        public int RecallFiles { get { return _recall.Count; } }

        // Encodes a message body; registered file texts inside it become their own token runs (recorded in _spans).
        List<int> EncodeBody(string prefix, string text, int at)
        {
            List<int> ids = new List<int>();
            string rest = text;
            bool any = true;
            while (any)
            {
                any = false;
                int best = -1; string seg = null;
                foreach (string s in _segIds.Keys)
                {
                    int i = rest.IndexOf(s, StringComparison.Ordinal);
                    if (i >= 0 && (best < 0 || i < best)) { best = i; seg = s; }
                }
                if (seg == null) break;
                ids.AddRange(Tokenizer.Encode(prefix + rest.Substring(0, best), false, false));
                prefix = "";
                Span sp = new Span(); sp.Start = at + ids.Count; sp.Len = _segIds[seg].Count; sp.Key = seg;
                _spans.Add(sp);
                ids.AddRange(_segIds[seg]);
                rest = rest.Substring(best + seg.Length);
                any = true;
            }
            ids.AddRange(Tokenizer.Encode(prefix + rest, false, false));
            return ids;
        }

        void StoreRecall(string key, KvSnapshot s)
        {
            if (_recall.ContainsKey(key)) return;
            _recall[key] = s; _recallOrder.Add(key); _recallBytes += s.Bytes;
            while (_recallBytes > RecallBudget && _recallOrder.Count > 1)
            {
                string old = _recallOrder[0]; _recallOrder.RemoveAt(0);
                _recallBytes -= _recall[old].Bytes; _recall.Remove(old);
            }
        }

        public List<int> LastReplyIds = new List<int>();   // tokens of the last reply as sampled

        // ---- prompt-lookup speculation ----
        public static bool Speculate = true;
        public static int GuessKeepTenths = 7;   // keep guessing while at least this many tenths of guesses are kept
        const int DraftMax = 8, NgramMax = 4, NgramMin = 3;

        // A draft answer written during a typing pause (WebServer answer-while-typing): searched for guesses after the
        // context itself.
        public List<int> Hint;

        // The tokens that followed the most recent earlier occurrence of the context's last n tokens (n = 4 .. 3), in the
        // context, else in the typing-pause draft.
        List<int> Draft(List<int> h, int room)
        {
            List<int> d = DraftFrom(h, h, room);
            if (d == null && Hint != null && Hint.Count > 0) d = DraftFrom(h, Hint, room);
            if (d != null && d.Exists(delegate(int t) { return t < 0; })) d = null;   // never guess image tokens
            return d;
        }

        static List<int> DraftFrom(List<int> h, List<int> src, int room)
        {
            int n0 = h.Count;
            if (room < 2 || n0 < NgramMin + 1) return null;
            for (int n = NgramMax; n >= NgramMin; n--)
            {
                if (n0 <= n) continue;
                bool self = ReferenceEquals(src, h);
                int last = self ? n0 - n - 1 : src.Count - n, stop = Math.Max(0, last - 32768);
                for (int i = last; i >= stop; i--)
                {
                    bool same = true;
                    for (int j = 0; j < n && same; j++) same = src[i + j] == h[n0 - n + j];
                    if (!same) continue;
                    int from = i + n, take = Math.Min(Math.Min(DraftMax, room - 1), (self ? n0 : src.Count) - from);
                    if (take <= 0) continue;
                    return src.GetRange(from, take);
                }
            }
            return null;
        }

        // Token ids of recent replies exactly as sampled, by their text. Re-encoding a reply's text usually gives other
        // tokens than the model produced (BPE merges differ), which broke the prompt-cache match at that reply and made
        // every follow-up (the code check, the next message) re-read it: 1,264 tokens = 4-5 s on Gemma 12B.
        readonly Dictionary<string, List<int>> _sampled = new Dictionary<string, List<int>>();
        readonly Queue<string> _sampledOrder = new Queue<string>();

        List<int> ReplyIds(string text)
        {
            List<int> ids;
            if (_sampled.TryGetValue(text, out ids)) return ids;
            return Tokenizer.Encode(text.Trim(), false, false);
        }

        void RememberReply(string text, List<int> ids)
        {
            if (text.Length == 0 || _sampled.ContainsKey(text)) return;
            _sampled[text] = ids;
            _sampledOrder.Enqueue(text);
            while (_sampledOrder.Count > 32) _sampled.Remove(_sampledOrder.Dequeue());
        }

        // Prompt token ids for a conversation (Gemma 4 template); ends with an open model turn.
        public List<int> Template(IList<ChatMessage> messages)
        {
            _spans = new List<Span>();
            return GemmaTemplate(messages);
        }

        // Runs a short throwaway generation so every GPU pipeline is created and the first real prompt starts at full
        // speed; the cache is cleared afterwards.
        public void WarmUp()
        {
            SamplerSettings s = new SamplerSettings(); s.Temperature = 0;
            List<ChatMessage> m = new List<ChatMessage>();
            m.Add(new ChatMessage("system", "Warm up.")); m.Add(new ChatMessage("user", "Hi"));
            Generate(m, s, 2, null, null);
            ClearCache();
        }

        public void ClearCache() { _fed.Clear(); _model.Reset(); }

        // VRAM of the GPU this model runs on (this process's use and its current budget); false on the CPU.
        public bool Vram(out ulong used, out ulong budget)
        {
            used = 0; budget = 0;
            return _gpu != null && _gpu.MemoryBudget(out used, out budget);
        }

        // Tokens currently held in the context (KV cache) for the conversation.
        public int UsedTokens { get { return _fed.Count; } }

        // Generates a reply to the conversation. Streams text through onText; returns stats.
        // Oldest non-system messages are dropped when the prompt would not leave room for maxTokens.
        // Called after each prompt chunk with (tokens done, tokens to do), e.g. to show progress on the slow CPU path.
        public Action<int, int> PrefillProgress;

        public GenerationStats Generate(List<ChatMessage> messages, SamplerSettings settings, int maxTokens, TextCallback onText, CancelCheck cancel)
        {
            lock (GpuGate.Lock) return GenerateLocked(messages, settings, maxTokens, onText, cancel);
        }

        // Fill-in-the-middle (code completion): the prefix/suffix prompt in the model's FIM format when its vocabulary has
        // one (<|fim_prefix|>..), with no chat template; otherwise an instructed completion through
        // the chat template. The tail of the prefix and the head of the suffix are kept when they are too long.
        public GenerationStats GenerateFim(string prefix, string suffix, SamplerSettings settings, int maxTokens, TextCallback onText, CancelCheck cancel)
        {
            int pre = TokenId("<|fim_prefix|>"), suf = TokenId("<|fim_suffix|>"), mid = TokenId("<|fim_middle|>");
            bool fim = pre >= 0 && suf >= 0 && mid >= 0 && suffix != null;
            if (Dbg.On) Dbg.Msg("engine", "code completion (" + (fim ? "FIM tokens" : "instructed") + ") for " + (Dbg.Source ?? "?") + "\n----- before cursor -----\n" + (prefix ?? "") + "\n----- after cursor -----\n" + (suffix ?? ""));
            if (!fim)
            {
                // Instruct models without FIM tokens: ask through the chat template (raw continuation measured poor on
                // Gemma 4 12B: it repeated fragments of the prefix).
                const int Keep = 6000;
                string pre2 = prefix ?? "", suf2 = suffix ?? "";
                if (pre2.Length > Keep) pre2 = pre2.Substring(pre2.Length - Keep);
                if (suf2.Length > Keep / 3) suf2 = suf2.Substring(0, Keep / 3);
                List<ChatMessage> m = new List<ChatMessage>();
                m.Add(new ChatMessage("system", "You are a code completion engine. The user sends a file with the cursor marked <CURSOR>. " +
                    "Reply with only the text to insert at the cursor: no explanation, no code fences, nothing that is already before or after it. " +
                    "Insert a short, natural continuation (finish the line or the block). If nothing fits, reply with nothing."));
                m.Add(new ChatMessage("user", pre2 + "<CURSOR>" + suf2));
                return Generate(m, settings, maxTokens, onText, cancel);
            }
            int budget = Math.Max(64, ContextLength - Math.Min(maxTokens, ContextLength / 2) - 8);
            List<int> p = Tokenizer.Encode(prefix ?? "", false, false);
            List<int> s = Tokenizer.Encode(suffix, false, false);
            if (s.Count > budget / 4) s.RemoveRange(budget / 4, s.Count - budget / 4);
            if (p.Count + s.Count > budget) p.RemoveRange(0, p.Count + s.Count - budget);
            List<int> prompt = new List<int>();
            if (Tokenizer.AddBos && Tokenizer.BosId >= 0) prompt.Add(Tokenizer.BosId);
            prompt.Add(pre); prompt.AddRange(p); prompt.Add(suf); prompt.AddRange(s); prompt.Add(mid);
            _spans = new List<Span>();
            lock (GpuGate.Lock) return Run(prompt, settings, maxTokens, onText, cancel, false);
        }

        GenerationStats GenerateLocked(List<ChatMessage> messages, SamplerSettings settings, int maxTokens, TextCallback onText, CancelCheck cancel)
        {
            List<ChatMessage> msgs = new List<ChatMessage>(messages);
            List<int> prompt = Template(msgs);
            int room = Math.Max(16, Math.Min(maxTokens, ContextLength / 2));
            while (prompt.Count + room > ContextLength)
            {
                int drop = msgs.FindIndex(delegate(ChatMessage m) { return m.Role != "system"; });
                if (drop < 0 || drop >= msgs.Count - 1) break;
                msgs.RemoveAt(drop);
                prompt = Template(msgs);
            }
            Dbg.Prompt(msgs);   // debug mode: exactly what the model reads (after any old turns were dropped to fit)
            if (prompt.Count >= ContextLength) throw new InvalidOperationException("The message is too long for the context window (" + ContextLength + " tokens).");
            return Run(prompt, settings, maxTokens, onText, cancel, true);
        }

        // Stash: one saved cache for a long conversation, so a short unrelated request in between (an editor's code
        // completions, chat titles, summaries) does not cost the next turn a full re-read. VS Code's agent prompt is
        // ~9k tokens, ~50 s to read on Gemma 12B, and each completion wiped it (2026-10-16). Gemma GPU (fp16 cache) only.
        public static int StashMinTokens = 2048;
        KvSnapshot _stash;
        List<int> _stashIds;

        static int Common(List<int> a, List<int> b)
        {
            int n = 0, max = Math.Min(a.Count, b.Count);
            while (n < max && a[n] == b[n]) n++;
            return n;
        }

        void StashSwap(List<int> prompt)
        {
            if (!_model.CanRecall) return;
            int cur = Common(_fed, prompt);
            int stashed = _stash != null ? Common(_stashIds, prompt) : 0;
            bool curLong = _fed.Count >= StashMinTokens && cur < _fed.Count / 2;   // about to throw away a long cache
            try
            {
                if (_stash != null && stashed >= StashMinTokens && stashed > cur + 256)
                {
                    // the stashed conversation continues: put it back (and stash what it replaces if that is long too)
                    KvSnapshot keep = curLong ? _model.CaptureKv(0, _fed.Count) : null;
                    List<int> keepIds = keep != null ? new List<int>(_fed) : null;
                    Dbg.Msg("engine", "stash: restoring the saved conversation cache (" + _stashIds.Count + " tokens)");
                    _model.SpliceKv(_stash, 0);
                    _fed.Clear();
                    _fed.AddRange(_stashIds);
                    _stash = keep; _stashIds = keepIds;
                }
                else if (curLong)
                {
                    _stash = _model.CaptureKv(0, _fed.Count);
                    Dbg.Msg("engine", "stash: saved the conversation cache (" + _fed.Count + " tokens, " + (_stash.Bytes >> 20) + " MB) before a different prompt");
                    _stashIds = new List<int>(_fed);
                }
            }
            catch (Exception)
            {
                // e.g. not enough memory for the snapshot: fall back to re-reading
                _stash = null; _stashIds = null;
                _fed.Clear(); _model.Reset();
            }
        }

        GenerationStats Run(List<int> prompt, SamplerSettings settings, int maxTokens, TextCallback onText, CancelCheck cancel, bool chat)
        {
            GenerationStats st = new GenerationStats();

            StashSwap(prompt);
            // Reuse the cached prefix.
            int reuse = 0;
            while (reuse < _fed.Count && reuse < prompt.Count - 1 && _fed[reuse] == prompt[reuse]) reuse++;
            if (reuse > 0 && reuse < _model.MinReuse(_fed.Count)) reuse = 0;   // ring cache no longer holds what that would need
            reuse = ImageTokens.ReuseStart(prompt, reuse);   // never resume reading in the middle of an image
            _fed.RemoveRange(reuse, _fed.Count - reuse);
            st.ReusedTokens = reuse;
            Dbg.Msg("engine", "prompt " + prompt.Count + " tokens: " + reuse + " reused from the cache, " + (prompt.Count - reuse) + " to read (context " + ContextLength + ")");
            st.PromptTokens = prompt.Count - reuse;

            Stopwatch sw = Stopwatch.StartNew();
            float[] logits = null;
            // The prompt is fed in chunks so Stop stays responsive: 512 tokens on the GPU (~1-2 s each with batched
            // prefill), 8 on the CPU (a few tokens per second there, so a 512 chunk would ignore Stop for minutes).
            int chunk = Backend == "CPU" ? 8 : 512;
            List<Span> spans = _spans.FindAll(delegate(Span s) { return s.Start >= reuse && s.Start + s.Len < prompt.Count; });
            int pos = reuse, si = 0;
            while (pos < prompt.Count)
            {
                Span sp = si < spans.Count ? spans[si] : null;
                int end = sp != null ? sp.Start : prompt.Count;
                for (int i = pos, n; i < end; i += n)
                {
                    if (cancel != null && cancel()) { st.StopReason = "stopped"; return st; }
                    n = ImageTokens.Fit(prompt, i, chunk, end);   // an image is read in one piece
                    long pf0 = Dbg.On ? sw.ElapsedMilliseconds : 0;
                    logits = _model.Prefill(prompt, i, n);
                    if (Dbg.On) Dbg.Msg("engine", "read prompt tokens " + i + ".." + (i + n) + " in " + (sw.ElapsedMilliseconds - pf0) + " ms");
                    for (int j = 0; j < n; j++) _fed.Add(prompt[i + j]);
                    if (PrefillProgress != null) PrefillProgress(i + n - reuse, prompt.Count - reuse);
                }
                if (sp == null) break;
                si++;
                KvSnapshot snap = FindRecall(sp.Key);
                if (snap != null && snap.Count == sp.Len)
                {
                    // seen before: splice its cache instead of reading it
                    _model.SpliceKv(snap, sp.Start);
                    for (int j = 0; j < sp.Len; j++) _fed.Add(prompt[sp.Start + j]);
                    st.RecalledTokens += sp.Len;
                    _recallOrder.Remove(sp.Key); _recallOrder.Add(sp.Key);
                }
                else if (sp.Len >= RecallMinTokens)
                {
                    // First read of this file: read it on its own (after just the turn header), save that snapshot, then
                    // rebuild the conversation up to here and splice the file in. A snapshot taken inside the conversation
                    // would carry the question asked then (measured: a later chat about Write() got an answer about
                    // Resolve()); read alone, it is neutral and reusable by any later chat.
                    KvSnapshot fresh = ReadAlone(sp.Key, _segIds[sp.Key], cancel);
                    if (fresh == null) { st.StopReason = "stopped"; return st; }
                    for (int i = 0, n; i < sp.Start; i += n)
                    {
                        if (cancel != null && cancel()) { st.StopReason = "stopped"; return st; }
                        n = ImageTokens.Fit(prompt, i, chunk, sp.Start);
                        logits = _model.Prefill(prompt, i, n);
                        for (int j = 0; j < n; j++) _fed.Add(prompt[i + j]);
                    }
                    _model.SpliceKv(fresh, sp.Start);
                    for (int j = 0; j < sp.Len; j++) _fed.Add(prompt[sp.Start + j]);
                }
                else
                {
                    for (int i = sp.Start; i < sp.Start + sp.Len; i += chunk)
                    {
                        if (cancel != null && cancel()) { st.StopReason = "stopped"; return st; }
                        int n = Math.Min(chunk, sp.Start + sp.Len - i);
                        logits = _model.Prefill(prompt, i, n);
                        for (int j = 0; j < n; j++) _fed.Add(prompt[i + j]);
                    }
                }
                pos = sp.Start + sp.Len;
                if (PrefillProgress != null) PrefillProgress(pos - reuse, prompt.Count - reuse);
            }
            st.PromptSeconds = sw.Elapsed.TotalSeconds;

            Sampler sampler = new Sampler(settings);
            StringBuilder emitted = new StringBuilder();
            List<int> sampledIds = new List<int>();
            List<int> history = new List<int>(prompt);
            Decoder utf8 = Encoding.UTF8.GetDecoder();
            char[] chars = new char[64];
            sw.Restart();
            int pending = -1;   // a token already sampled while checking a guess (speculation)
            while (true)
            {
                foreach (int b in _banned) if (b < logits.Length) logits[b] = float.NegativeInfinity;
                int next = pending >= 0 ? pending : sampler.Sample(logits, history);
                pending = -1;
                if (next == _eot || next == Tokenizer.EosId) { st.StopReason = "end of turn"; break; }
                if (Tokenizer.IsSpecial(next)) { st.StopReason = "special token " + Encoding.UTF8.GetString(Tokenizer.TokenBytes(next, true)); break; }

                byte[] bytes = Tokenizer.TokenBytes(next, false);
                int nc = utf8.GetChars(bytes, 0, bytes.Length, chars, 0, false);
                if (nc > 0) { string piece = new string(chars, 0, nc); emitted.Append(piece); if (onText != null) onText(piece); }
                sampledIds.Add(next);
                st.GeneratedTokens++;
                history.Add(next);

                if (st.GeneratedTokens >= maxTokens) { st.StopReason = "max tokens"; break; }
                if (_fed.Count >= ContextLength) { st.StopReason = "context full"; break; }
                if (cancel != null && cancel()) { st.StopReason = "stopped"; break; }
                // Prompt-lookup speculation: when the last few tokens appeared earlier in the context (a file being
                // rewritten, code being quoted), the tokens that followed them there are a free guess for what comes next.
                // next + the guesses are fed in one batched pass; each guess is kept only if sampling the model at that
                // position gives that very token, so the output distribution is exactly that of plain decoding.
                // adaptive: after a few guesses, keep guessing only while at least 70% of them are kept (a wasted batched
                // check costs more than the decode steps it was meant to save; measured on Gemma 12B at 41% kept)
                bool guessing = Speculate && (st.DraftedTokens < 24 || st.AcceptedTokens * 10 >= st.DraftedTokens * GuessKeepTenths);
                List<int> draft = guessing ? Draft(history, maxTokens - st.GeneratedTokens) : null;
                bool batched = false;
                if (draft != null && draft.Count > 0)
                {
                    List<int> run = new List<int>(); run.Add(next); run.AddRange(draft);
                    List<int> seq = new List<int>(_fed); seq.AddRange(run);
                    if (_fed.Count + run.Count < ContextLength) batched = _model.PrefillRows(seq, _fed.Count, run.Count);
                    if (batched)
                    {
                        _fed.Add(next);
                        st.DraftedTokens += draft.Count;
                        int accepted = 0;
                        logits = _model.RowLogits(0);
                        bool stop = false;
                        for (int di = 0; di < draft.Count; di++)
                        {
                            foreach (int b in _banned) if (b < logits.Length) logits[b] = float.NegativeInfinity;
                            int tok = sampler.Sample(logits, history);
                            if (tok != draft[di])
                            {
                                // the model wants something else here: keep its own token, drop the rest of the guess
                                pending = tok;
                                break;
                            }
                            accepted++;
                            if (tok == _eot || tok == Tokenizer.EosId) { st.StopReason = "end of turn"; stop = true; break; }
                            if (Tokenizer.IsSpecial(tok)) { st.StopReason = "special token"; stop = true; break; }
                            byte[] tb = Tokenizer.TokenBytes(tok, false);
                            int tn = utf8.GetChars(tb, 0, tb.Length, chars, 0, false);
                            if (tn > 0) { string piece = new string(chars, 0, tn); emitted.Append(piece); if (onText != null) onText(piece); }
                            sampledIds.Add(tok);
                            st.GeneratedTokens++;
                            history.Add(tok);
                            _fed.Add(tok);
                            logits = _model.RowLogits(di + 1);
                            if (st.GeneratedTokens >= maxTokens) { st.StopReason = "max tokens"; stop = true; break; }
                            if (cancel != null && cancel()) { st.StopReason = "stopped"; stop = true; break; }
                        }
                        st.AcceptedTokens += accepted;
                        if (stop) break;
                        continue;
                    }
                }
                logits = _model.Forward(next, _fed.Count);
                _fed.Add(next);
            }
            st.GenerateSeconds = sw.Elapsed.TotalSeconds;
            Dbg.Msg("engine", "generated " + st.GeneratedTokens + " tokens in " + (int)(st.GenerateSeconds * 1000) + " ms (" + st.StopReason + "; guesses kept " + st.AcceptedTokens + "/" + st.DraftedTokens + ")");
            if (chat) { RememberReply(emitted.ToString(), sampledIds); LastReplyIds = sampledIds; }
            Dbg.Reply(emitted.ToString(), st.StopReason);
            return st;
        }

        public void Dispose()
        {
            if (_locked) { _locked = false; ModelLock.Release(); }
            if (_vision != null) { _vision.Dispose(); _vision = null; }
            _model.Dispose();
            if (_gpu != null) _gpu.Dispose();
            _gguf.Dispose();
        }
    }
}
