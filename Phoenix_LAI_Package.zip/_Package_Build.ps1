# Packs the whole app into Phoenix_LAI_Package.zip (built-in .NET zip, strongest level it has), then encodes it as
# Phoenix_LAI_Package.b64. Nothing to install.
#   powershell.exe -NoProfile -File _Package_Build.ps1
# The models (.gguf) are never packed: copy the models folder across separately.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$name = 'Phoenix_LAI_Package'
$zip = Join-Path $root "$name.zip"
$b64 = Join-Path $root "$name.b64"
Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem

foreach ($f in @($zip, $b64)) { if (Test-Path $f) { Remove-Item $f -Force } }

# Left out: git history, logs, other worktrees, test copies, the package itself and the models.
$skipDirs = @('.git', 'logs', '.claude\worktrees', '.claude\rag-eval-oldroot', 'nvidia\results', 'nvidia\logs')
$skipFiles = @("$name.zip", "$name.b64", "$name.7z")

$files = Get-ChildItem $root -Recurse -File -Force | Where-Object {
    $rel = $_.FullName.Substring($root.Length + 1)
    if ($skipFiles -contains $rel) { return $false }
    foreach ($d in $skipDirs) { if ($rel.StartsWith($d + '\', [StringComparison]::OrdinalIgnoreCase)) { return $false } }
    if ($rel -like '*.gguf') { return $false }
    $true
}

$level = [IO.Compression.CompressionLevel]::Optimal   # .NET Framework's strongest setting
$archive = [IO.Compression.ZipFile]::Open($zip, [IO.Compression.ZipArchiveMode]::Create)
try {
    $n = 0
    foreach ($f in $files) {
        $rel = $f.FullName.Substring($root.Length + 1).Replace('\', '/')
        [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $f.FullName, $rel, $level)
        $n++
        if ($n % 200 -eq 0) { Write-Host "  $n files..." }
    }
} finally { $archive.Dispose() }
Write-Host "$n files packed."

# Stream the base64 so large archives never sit in memory.
$in = [IO.File]::OpenRead($zip)
$out = [IO.File]::Create($b64)
try {
    $cs = New-Object Security.Cryptography.CryptoStream($out, (New-Object Security.Cryptography.ToBase64Transform), 'Write')
    $in.CopyTo($cs, 1MB)
    $cs.FlushFinalBlock()
    $cs.Dispose()
} finally { $in.Dispose(); $out.Dispose() }

'{0}: {1:N1} MB' -f (Split-Path $zip -Leaf), ((Get-Item $zip).Length / 1MB)
'{0}: {1:N1} MB' -f (Split-Path $b64 -Leaf), ((Get-Item $b64).Length / 1MB)
