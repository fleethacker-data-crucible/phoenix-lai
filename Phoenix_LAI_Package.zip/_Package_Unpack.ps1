# Converts Phoenix_LAI_Package.b64 (next to this script) back into Phoenix_LAI_Package.zip.
#   powershell.exe -NoProfile -File _Package_Unpack.ps1
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$b64 = Join-Path $root 'Phoenix_LAI_Package.b64'
$zip = Join-Path $root 'Phoenix_LAI_Package.zip'
if (-not (Test-Path $b64)) { throw "Not found: $b64" }
if (Test-Path $zip) { Remove-Item $zip -Force }

# Stream-decode; FromBase64Transform skips whitespace/line breaks.
$in = [IO.File]::OpenRead($b64)
$out = [IO.File]::Create($zip)
try {
    $xf = New-Object Security.Cryptography.FromBase64Transform([Security.Cryptography.FromBase64TransformMode]::IgnoreWhiteSpaces)
    $cs = New-Object Security.Cryptography.CryptoStream($in, $xf, 'Read')
    $cs.CopyTo($out, 1MB)
    $cs.Dispose()
} finally { $in.Dispose(); $out.Dispose() }

'Created {0} ({1:N1} MB)' -f $zip, ((Get-Item $zip).Length / 1MB)
