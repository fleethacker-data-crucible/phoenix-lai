@echo off
rem Builds Phoenix_LAI_Package.zip and Phoenix_LAI_Package.b64 next to this file.
rem The models (.gguf) are left out: copy the models folder across separately.
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0_Package_Build.ps1" %*
echo.
pause
