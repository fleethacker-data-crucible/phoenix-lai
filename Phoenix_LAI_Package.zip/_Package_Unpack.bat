@echo off
rem Turns Phoenix_LAI_Package.b64 next to this file back into Phoenix_LAI_Package.zip.
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0_Package_Unpack.ps1" %*
echo.
pause
