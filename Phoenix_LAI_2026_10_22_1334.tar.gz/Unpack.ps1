# Turns a Phoenix_LAI_*.package (base64) back into its .tar.gz, next to it.
# With no -Package, uses the newest Phoenix_LAI_*.package in this folder. Extract with: tar -xzf <file>.tar.gz
# Windows PowerShell 5.1: powershell.exe -NoProfile -ExecutionPolicy Bypass -File Unpack.ps1 [-Package <file>]
param([string]$Package)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not $Package) {
    $newest = Get-ChildItem $root -Filter 'Phoenix_LAI_*.package' -File | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $newest) { throw "No Phoenix_LAI_*.package in $root." }
    $Package = $newest.FullName
}
$Package = (Resolve-Path $Package).Path
$gz = [IO.Path]::ChangeExtension($Package, '.tar.gz')
if (Test-Path $gz) { throw "$gz already exists; move or delete it first." }

$in = [IO.File]::OpenRead($Package); $out = [IO.File]::Create($gz)
try {
    $dec = New-Object Security.Cryptography.CryptoStream($in, (New-Object Security.Cryptography.FromBase64Transform), 'Read')
    $dec.CopyTo($out, 1MB); $dec.Dispose()
} catch { $out.Dispose(); Remove-Item $gz -Force -ErrorAction SilentlyContinue; throw } finally { $in.Dispose(); $out.Dispose() }

# Make sure it is a readable gzip (reads it through once).
$f = [IO.File]::OpenRead($gz)
try {
    $g = New-Object IO.Compression.GZipStream($f, [IO.Compression.CompressionMode]::Decompress)
    $buf = New-Object byte[] 1MB; $total = 0L
    while (($n = $g.Read($buf, 0, $buf.Length)) -gt 0) { $total += $n }
    $g.Dispose()
} finally { $f.Dispose() }
'{0}: {1:N1} MB ({2:N1} MB unpacked tar)' -f (Split-Path $gz -Leaf), ((Get-Item $gz).Length / 1MB), ($total / 1MB)
